import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/bt_service.dart';
import 'screens/dashboard_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/log_screen.dart';
import 'screens/connect_screen.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(
    ChangeNotifierProvider(
      create: (_) => BtService(),
      child: const QuickShifterApp(),
    ),
  );
}

class QuickShifterApp extends StatelessWidget {
  const QuickShifterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quick Shifter',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  static const _screens = [
    DashboardScreen(),
    SettingsScreen(),
    LogScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final bt = context.watch<BtService>();

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('QUICK SHIFTER'),
        centerTitle: false,
        actions: [
          // BT status chip
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ConnectScreen()),
            ),
            child: Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: bt.connected
                    ? AppTheme.accent.withOpacity(0.12)
                    : AppTheme.bgCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: bt.connected
                      ? AppTheme.accent.withOpacity(0.4)
                      : AppTheme.bgBar,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    bt.connecting
                        ? Icons.bluetooth_searching_rounded
                        : bt.connected
                            ? Icons.bluetooth_connected_rounded
                            : Icons.bluetooth_disabled_rounded,
                    size: 14,
                    color: bt.connecting
                        ? AppTheme.warning
                        : bt.connected
                            ? AppTheme.accent
                            : AppTheme.textSec,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    bt.connecting
                        ? 'Menghubungkan...'
                        : bt.connected
                            ? bt.deviceName
                            : 'Tidak terhubung',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: bt.connecting
                          ? AppTheme.warning
                          : bt.connected
                              ? AppTheme.accent
                              : AppTheme.textSec,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      body: _screens[_tab],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.speed_rounded),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.tune_rounded),
            label: 'Setting',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.terminal_rounded),
            label: 'Log',
          ),
        ],
      ),
    );
  }
}
