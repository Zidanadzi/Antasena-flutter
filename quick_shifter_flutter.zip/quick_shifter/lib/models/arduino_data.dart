class ArduinoData {
  final int rpm;
  final int shifts;
  final int killTime;
  final int sensitivity;
  final bool enabled;

  const ArduinoData({
    this.rpm = 0,
    this.shifts = 0,
    this.killTime = 65,
    this.sensitivity = 500,
    this.enabled = true,
  });

  factory ArduinoData.fromJson(Map<String, dynamic> json) => ArduinoData(
        rpm: (json['rpm'] as num?)?.toInt() ?? 0,
        shifts: (json['shifts'] as num?)?.toInt() ?? 0,
        killTime: (json['killTime'] as num?)?.toInt() ?? 65,
        sensitivity: (json['sensitivity'] as num?)?.toInt() ?? 500,
        enabled: json['enabled'] as bool? ?? true,
      );

  ArduinoData copyWith({
    int? rpm,
    int? shifts,
    int? killTime,
    int? sensitivity,
    bool? enabled,
  }) =>
      ArduinoData(
        rpm: rpm ?? this.rpm,
        shifts: shifts ?? this.shifts,
        killTime: killTime ?? this.killTime,
        sensitivity: sensitivity ?? this.sensitivity,
        enabled: enabled ?? this.enabled,
      );

  String rpmZone() {
    if (rpm < 1500) return 'IDLE';
    if (rpm < 4500) return 'RENDAH';
    if (rpm < 8000) return 'NORMAL';
    if (rpm < 11000) return 'POWER';
    return 'REDLINE';
  }

  double rpmPercent() => (rpm / 15000).clamp(0, 1);
}

class LogEntry {
  final DateTime time;
  final String message;
  final LogType type;

  LogEntry({required this.message, this.type = LogType.info})
      : time = DateTime.now();

  String get timeStr {
    final t = time;
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final s = t.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }
}

enum LogType { info, ok, error, shift }
