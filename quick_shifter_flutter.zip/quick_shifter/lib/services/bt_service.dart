import 'dart:convert';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/arduino_data.dart';

class BtService extends ChangeNotifier {
  BluetoothConnection? _connection;
  StreamSubscription? _sub;

  bool connected = false;
  bool connecting = false;
  String deviceName = '';
  String deviceMac = '';

  ArduinoData data = const ArduinoData();
  final List<LogEntry> logs = [];

  String _buffer = '';

  // ── Simpan MAC address terakhir ──────────────────────────────
  Future<void> saveLastMac(String mac) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('last_mac', mac);
  }

  Future<String?> getLastMac() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('last_mac');
  }

  // ── Scan paired devices ──────────────────────────────────────
  Future<List<BluetoothDevice>> getPairedDevices() async {
    try {
      return await FlutterBluetoothSerial.instance.getBondedDevices();
    } catch (_) {
      return [];
    }
  }

  // ── Connect ──────────────────────────────────────────────────
  Future<void> connect(BluetoothDevice device) async {
    if (connecting || connected) return;
    connecting = true;
    deviceName = device.name ?? 'HC-05';
    deviceMac = device.address;
    notifyListeners();

    addLog('Menghubungkan ke $deviceName...', LogType.info);

    try {
      _connection = await BluetoothConnection.toAddress(device.address)
          .timeout(const Duration(seconds: 10));

      connected = true;
      connecting = false;
      await saveLastMac(device.address);
      addLog('Terhubung ke $deviceName', LogType.ok);
      notifyListeners();

      _buffer = '';
      _sub = _connection!.input!.listen(_onData, onDone: _onDisconnect);
    } catch (e) {
      connecting = false;
      connected = false;
      addLog('Gagal terhubung: $e', LogType.error);
      notifyListeners();
    }
  }

  // ── Disconnect ───────────────────────────────────────────────
  Future<void> disconnect() async {
    await _sub?.cancel();
    await _connection?.close();
    connected = false;
    deviceName = '';
    addLog('Koneksi diputus.', LogType.error);
    notifyListeners();
  }

  // ── Receive data ─────────────────────────────────────────────
  void _onData(Uint8List bytes) {
    _buffer += ascii.decode(bytes, allowInvalid: true);
    while (_buffer.contains('\n')) {
      final idx = _buffer.indexOf('\n');
      final line = _buffer.substring(0, idx).trim();
      _buffer = _buffer.substring(idx + 1);
      if (line.isNotEmpty) _parseLine(line);
    }
  }

  void _parseLine(String line) {
    try {
      final json = jsonDecode(line) as Map<String, dynamic>;
      if (json.containsKey('rpm')) {
        final prev = data;
        data = ArduinoData.fromJson(json);
        if (data.shifts > prev.shifts) {
          addLog(
            'SHIFT #${data.shifts} — ${data.rpm} RPM — cut ${data.killTime}ms',
            LogType.shift,
          );
        }
      } else if (json.containsKey('status')) {
        addLog('Arduino >> ${json['status']}', LogType.ok);
      }
    } catch (_) {
      addLog('RX >> $line', LogType.info);
    }
    notifyListeners();
  }

  void _onDisconnect() {
    connected = false;
    addLog('Koneksi terputus.', LogType.error);
    notifyListeners();
  }

  // ── Send commands ─────────────────────────────────────────────
  void send(String cmd) {
    if (!connected) return;
    try {
      _connection!.output.add(ascii.encode('$cmd\n'));
      addLog('TX >> $cmd', LogType.info);
      notifyListeners();
    } catch (e) {
      addLog('Gagal kirim: $e', LogType.error);
      notifyListeners();
    }
  }

  void setKillTime(int ms) => send('SET_KILL:$ms');
  void setSensitivity(int v) => send('SET_SENS:$v');
  void toggleQS(bool on) => send(on ? 'QS_ON' : 'QS_OFF');
  void resetCount() => send('RESET_COUNT');
  void ping() => send('PING');

  // ── Log ───────────────────────────────────────────────────────
  void addLog(String msg, LogType type) {
    logs.insert(0, LogEntry(message: msg, type: type));
    if (logs.length > 200) logs.removeLast();
  }

  void clearLog() {
    logs.clear();
    notifyListeners();
  }
}
