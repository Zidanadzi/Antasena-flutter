import 'package:flutter/material.dart';

class AppTheme {
  static const Color bg         = Color(0xFF060E0D);
  static const Color bgCard     = Color(0xFF0C1A18);
  static const Color bgBar      = Color(0xFF0F2220);
  static const Color accent     = Color(0xFF00D4B4);
  static const Color accentDim  = Color(0xFF008C78);
  static const Color textPri    = Color(0xFFD4EFEB);
  static const Color textSec    = Color(0xFF6AAFA6);
  static const Color danger     = Color(0xFFFF4C4C);
  static const Color warning    = Color(0xFFFFA500);
  static const Color success    = Color(0xFF00D4B4);

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: bg,
    fontFamily: 'monospace',
    colorScheme: const ColorScheme.dark(
      primary: accent,
      secondary: accentDim,
      surface: bgCard,
      error: danger,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: bg,
      foregroundColor: textPri,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: textSec,
        fontSize: 11,
        letterSpacing: 3,
        fontWeight: FontWeight.w600,
      ),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: bg,
      selectedItemColor: accent,
      unselectedItemColor: textSec,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    sliderTheme: const SliderThemeData(
      activeTrackColor: accent,
      inactiveTrackColor: bgBar,
      thumbColor: accent,
      overlayColor: Color(0x2200D4B4),
      trackHeight: 3,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? bg : textSec,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? accent : bgBar,
      ),
    ),
  );
}
