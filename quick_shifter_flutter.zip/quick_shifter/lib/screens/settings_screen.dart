import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bt_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  double _killTime = 65;
  double _sensitivity = 500;
  bool _init = false;

  @override
  Widget build(BuildContext context) {
    final bt = context.watch<BtService>();
    final d = bt.data;

    if (!_init && bt.connected) {
      _killTime = d.killTime.toDouble();
      _sensitivity = d.sensitivity.toDouble();
      _init = true;
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('PARAMETER SHIFT'),
          const SizedBox(height: 12),

          // ── Kill Time ─────────────────────────────────────────
          _SliderCard(
            title: 'Kill Time',
            subtitle: 'Durasi cut ignisi saat pindah gigi',
            value: _killTime,
            min: 20,
            max: 150,
            unit: 'ms',
            divisions: 130,
            enabled: bt.connected,
            hint: _killTimeHint(_killTime.toInt()),
            onChanged: (v) => setState(() => _killTime = v),
            onChangeEnd: (v) => bt.setKillTime(v.toInt()),
          ),
          const SizedBox(height: 12),

          // ── Sensitivity ───────────────────────────────────────
          _SliderCard(
            title: 'Sensitivitas Sensor',
            subtitle: 'Threshold ADC untuk deteksi tekanan gigi',
            value: _sensitivity,
            min: 100,
            max: 900,
            unit: 'ADC',
            divisions: 80,
            enabled: bt.connected,
            hint: _sensHint(_sensitivity.toInt()),
            onChanged: (v) => setState(() => _sensitivity = v),
            onChangeEnd: (v) => bt.setSensitivity(v.toInt()),
          ),
          const SizedBox(height: 24),

          _sectionTitle('PANDUAN TUNING'),
          const SizedBox(height: 12),
          _GuideCard(
            items: const [
              _GuideItem(
                icon: Icons.speed_rounded,
                title: 'Kill Time Rendah (20–50ms)',
                desc: 'Shift sangat responsif, cocok untuk motor sport bertenaga tinggi.',
              ),
              _GuideItem(
                icon: Icons.tune_rounded,
                title: 'Kill Time Sedang (55–80ms)',
                desc: 'Seimbang antara respon dan kehalusan perpindahan gigi.',
              ),
              _GuideItem(
                icon: Icons.directions_bike_rounded,
                title: 'Kill Time Tinggi (85–150ms)',
                desc: 'Perpindahan lebih lambat, cocok untuk motor harian.',
              ),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _sectionTitle(String t) => Text(
        t,
        style: const TextStyle(
          fontSize: 10,
          color: AppTheme.textSec,
          letterSpacing: 2,
          fontWeight: FontWeight.w700,
        ),
      );

  String _killTimeHint(int v) {
    if (v < 50) return 'Sport';
    if (v < 90) return 'Balanced';
    return 'Smooth';
  }

  String _sensHint(int v) {
    if (v < 300) return 'Sangat sensitif';
    if (v < 600) return 'Normal';
    return 'Keras';
  }
}

class _SliderCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double value;
  final double min;
  final double max;
  final String unit;
  final int divisions;
  final bool enabled;
  final String hint;
  final ValueChanged<double> onChanged;
  final ValueChanged<double> onChangeEnd;

  const _SliderCard({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.min,
    required this.max,
    required this.unit,
    required this.divisions,
    required this.enabled,
    required this.hint,
    required this.onChanged,
    required this.onChangeEnd,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPri)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: const TextStyle(
                          fontSize: 11, color: AppTheme.textSec)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  RichText(
                    text: TextSpan(children: [
                      TextSpan(
                        text: value.toInt().toString(),
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.accent,
                          fontFamily: 'monospace',
                        ),
                      ),
                      TextSpan(
                        text: ' $unit',
                        style: const TextStyle(
                            fontSize: 12, color: AppTheme.textSec),
                      ),
                    ]),
                  ),
                  Text(hint,
                      style: const TextStyle(
                          fontSize: 10, color: AppTheme.accentDim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            onChanged: enabled ? onChanged : null,
            onChangeEnd: enabled ? onChangeEnd : null,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('${min.toInt()} $unit',
                  style:
                      const TextStyle(fontSize: 10, color: AppTheme.textSec)),
              Text('${max.toInt()} $unit',
                  style:
                      const TextStyle(fontSize: 10, color: AppTheme.textSec)),
            ],
          ),
        ],
      ),
    );
  }
}

class _GuideCard extends StatelessWidget {
  final List<_GuideItem> items;
  const _GuideCard({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: items
            .map((i) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(i.icon, size: 18, color: AppTheme.accent),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(i.title,
                                style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.textPri)),
                            const SizedBox(height: 2),
                            Text(i.desc,
                                style: const TextStyle(
                                    fontSize: 11, color: AppTheme.textSec)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ))
            .toList(),
      ),
    );
  }
}

class _GuideItem {
  final IconData icon;
  final String title;
  final String desc;
  const _GuideItem({required this.icon, required this.title, required this.desc});
}
