import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bt_service.dart';
import '../theme/app_theme.dart';
import '../widgets/rpm_gauge.dart';
import '../widgets/stat_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bt = context.watch<BtService>();
    final d = bt.data;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          // ── Zone label ───────────────────────────────────────
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: _zoneColor(d.rpm).withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '● ${d.rpmZone()}',
              style: TextStyle(
                fontSize: 11,
                color: _zoneColor(d.rpm),
                letterSpacing: 2,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 8),

          // ── RPM Gauge ─────────────────────────────────────────
          RpmGauge(rpm: bt.connected ? d.rpm : 0, size: 280),
          const SizedBox(height: 4),

          // ── RPM Bar ───────────────────────────────────────────
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: bt.connected ? d.rpmPercent() : 0,
              minHeight: 4,
              backgroundColor: AppTheme.bgBar,
              valueColor: AlwaysStoppedAnimation(_zoneColor(d.rpm)),
            ),
          ),
          const SizedBox(height: 16),

          // ── Stat cards ────────────────────────────────────────
          Row(
            children: [
              Expanded(
                child: StatCard(
                  label: 'TOTAL SHIFT',
                  value: d.shifts.toString(),
                  unit: 'kali',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: StatCard(
                  label: 'KILL TIME',
                  value: d.killTime.toString(),
                  unit: 'ms',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: StatCard(
                  label: 'SENSOR',
                  value: d.sensitivity.toString(),
                  unit: 'ADC',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // ── QS Toggle ─────────────────────────────────────────
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'QUICK SHIFTER',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppTheme.textSec,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      d.enabled ? 'Aktif' : 'Nonaktif',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: d.enabled ? AppTheme.success : AppTheme.danger,
                      ),
                    ),
                  ],
                ),
                Switch(
                  value: d.enabled,
                  onChanged: bt.connected ? (v) => bt.toggleQS(v) : null,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ── Action buttons ────────────────────────────────────
          Row(
            children: [
              Expanded(
                child: _ActionBtn(
                  label: 'RESET COUNTER',
                  icon: Icons.refresh_rounded,
                  onTap: bt.connected ? bt.resetCount : null,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ActionBtn(
                  label: 'PING',
                  icon: Icons.wifi_tethering_rounded,
                  onTap: bt.connected ? bt.ping : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Color _zoneColor(int rpm) {
    if (rpm < 8000) return AppTheme.accent;
    if (rpm < 11000) return AppTheme.warning;
    return AppTheme.danger;
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;

  const _ActionBtn({required this.label, required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: onTap != null ? AppTheme.accent.withOpacity(0.3) : Colors.transparent,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: 16,
                color: onTap != null ? AppTheme.accent : AppTheme.textSec),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: onTap != null ? AppTheme.accent : AppTheme.textSec,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
