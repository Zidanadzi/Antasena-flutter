import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import '../services/bt_service.dart';
import '../theme/app_theme.dart';

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  List<BluetoothDevice> _devices = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _requestAndLoad();
  }

  Future<void> _requestAndLoad() async {
    setState(() => _loading = true);
    await [
      Permission.bluetooth,
      Permission.bluetoothConnect,
      Permission.bluetoothScan,
    ].request();
    await _loadDevices();
  }

  Future<void> _loadDevices() async {
    setState(() => _loading = true);
    final bt = context.read<BtService>();
    final devices = await bt.getPairedDevices();
    setState(() {
      _devices = devices;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bt = context.watch<BtService>();

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('PILIH PERANGKAT'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.accent),
            onPressed: _loadDevices,
          ),
        ],
      ),
      body: Column(
        children: [
          // ── Status banner ────────────────────────────────────
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            color: bt.connected
                ? AppTheme.success.withOpacity(0.1)
                : AppTheme.danger.withOpacity(0.1),
            child: Row(
              children: [
                Icon(
                  bt.connected
                      ? Icons.bluetooth_connected_rounded
                      : Icons.bluetooth_disabled_rounded,
                  size: 16,
                  color: bt.connected ? AppTheme.success : AppTheme.danger,
                ),
                const SizedBox(width: 8),
                Text(
                  bt.connected
                      ? 'Terhubung ke ${bt.deviceName} (${bt.deviceMac})'
                      : 'Belum terhubung',
                  style: TextStyle(
                    fontSize: 12,
                    color:
                        bt.connected ? AppTheme.success : AppTheme.danger,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (bt.connected) ...[
                  const Spacer(),
                  GestureDetector(
                    onTap: bt.disconnect,
                    child: const Text(
                      'Putuskan',
                      style: TextStyle(
                          fontSize: 11,
                          color: AppTheme.danger,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ],
            ),
          ),

          // ── Device list ───────────────────────────────────────
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.accent),
                  )
                : _devices.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.bluetooth_searching_rounded,
                                size: 48, color: AppTheme.textSec),
                            const SizedBox(height: 12),
                            const Text('Tidak ada perangkat terpasang.',
                                style: TextStyle(color: AppTheme.textSec)),
                            const SizedBox(height: 8),
                            const Text(
                              'Pastikan HC-05 sudah dipair di\nPengaturan Bluetooth Android.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12, color: AppTheme.textSec),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton.icon(
                              onPressed: _loadDevices,
                              icon: const Icon(Icons.refresh_rounded, size: 16),
                              label: const Text('Refresh'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.bgCard,
                                foregroundColor: AppTheme.accent,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _devices.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final device = _devices[i];
                          final isHC05 = (device.name ?? '').contains('HC');
                          final isActive =
                              bt.connected && bt.deviceMac == device.address;
                          return _DeviceTile(
                            device: device,
                            isHC05: isHC05,
                            isActive: isActive,
                            connecting: bt.connecting,
                            onTap: () => bt.connect(device),
                          );
                        },
                      ),
          ),

          // ── Info footer ───────────────────────────────────────
          Container(
            padding: const EdgeInsets.all(16),
            color: AppTheme.bgCard,
            child: const Row(
              children: [
                Icon(Icons.info_outline_rounded,
                    size: 14, color: AppTheme.textSec),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'PIN default HC-05: 1234 atau 0000. Pair dulu di Pengaturan Bluetooth sebelum connect.',
                    style: TextStyle(fontSize: 11, color: AppTheme.textSec),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DeviceTile extends StatelessWidget {
  final BluetoothDevice device;
  final bool isHC05;
  final bool isActive;
  final bool connecting;
  final VoidCallback onTap;

  const _DeviceTile({
    required this.device,
    required this.isHC05,
    required this.isActive,
    required this.connecting,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isActive || connecting ? null : onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isActive
                ? AppTheme.accent
                : isHC05
                    ? AppTheme.accent.withOpacity(0.25)
                    : Colors.transparent,
            width: isActive ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isActive
                    ? AppTheme.accent.withOpacity(0.15)
                    : AppTheme.bgBar,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                isHC05
                    ? Icons.bluetooth_rounded
                    : Icons.devices_other_rounded,
                color: isActive ? AppTheme.accent : AppTheme.textSec,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        device.name ?? 'Unknown',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPri,
                        ),
                      ),
                      if (isHC05) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.accent.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'HC-05',
                            style: TextStyle(
                                fontSize: 9,
                                color: AppTheme.accent,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    device.address,
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppTheme.textSec,
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ),
            if (isActive)
              const Text(
                'AKTIF',
                style: TextStyle(
                    fontSize: 10,
                    color: AppTheme.accent,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1),
              )
            else
              const Icon(Icons.chevron_right_rounded,
                  color: AppTheme.textSec, size: 20),
          ],
        ),
      ),
    );
  }
}
