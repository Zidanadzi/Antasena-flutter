import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bt_service.dart';
import '../models/arduino_data.dart';
import '../theme/app_theme.dart';

class LogScreen extends StatelessWidget {
  const LogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bt = context.watch<BtService>();

    return Column(
      children: [
        // ── Header ───────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${bt.logs.length} entri',
                style:
                    const TextStyle(fontSize: 12, color: AppTheme.textSec),
              ),
              GestureDetector(
                onTap: bt.clearLog,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'Hapus',
                    style: TextStyle(fontSize: 11, color: AppTheme.textSec),
                  ),
                ),
              ),
            ],
          ),
        ),

        // ── Log list ──────────────────────────────────────────────
        Expanded(
          child: bt.logs.isEmpty
              ? const Center(
                  child: Text(
                    'Belum ada log.',
                    style: TextStyle(color: AppTheme.textSec, fontSize: 13),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: bt.logs.length,
                  itemBuilder: (_, i) {
                    final log = bt.logs[i];
                    return _LogRow(log: log);
                  },
                ),
        ),
      ],
    );
  }
}

class _LogRow extends StatelessWidget {
  final LogEntry log;
  const _LogRow({required this.log});

  Color get _color {
    switch (log.type) {
      case LogType.ok:
        return AppTheme.success;
      case LogType.error:
        return AppTheme.danger;
      case LogType.shift:
        return AppTheme.warning;
      default:
        return AppTheme.textSec;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '[${log.timeStr}]',
            style: const TextStyle(
              fontSize: 10,
              color: AppTheme.textSec,
              fontFamily: 'monospace',
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              log.message,
              style: TextStyle(
                fontSize: 11,
                color: _color,
                fontFamily: 'monospace',
                fontWeight: log.type == LogType.shift
                    ? FontWeight.w700
                    : FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
