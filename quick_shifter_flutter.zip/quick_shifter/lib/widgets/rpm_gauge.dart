import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class RpmGauge extends StatelessWidget {
  final int rpm;
  final double size;

  const RpmGauge({super.key, required this.rpm, this.size = 200});

  Color get _zoneColor {
    if (rpm < 4500) return AppTheme.accent;
    if (rpm < 8000) return AppTheme.accent;
    if (rpm < 11000) return AppTheme.warning;
    return AppTheme.danger;
  }

  @override
  Widget build(BuildContext context) {
    final pct = (rpm / 15000).clamp(0.0, 1.0);
    return SizedBox(
      width: size,
      height: size * 0.55,
      child: CustomPaint(
        painter: _GaugePainter(pct, _zoneColor),
        child: Center(
          child: Padding(
            padding: EdgeInsets.only(top: size * 0.18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _formatRpm(rpm),
                  style: TextStyle(
                    fontSize: size * 0.22,
                    fontWeight: FontWeight.w800,
                    color: _zoneColor,
                    fontFamily: 'monospace',
                    letterSpacing: -1,
                  ),
                ),
                Text(
                  'RPM',
                  style: TextStyle(
                    fontSize: size * 0.07,
                    color: AppTheme.textSec,
                    letterSpacing: 3,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatRpm(int v) {
    if (v >= 1000) {
      return '${(v / 1000).toStringAsFixed(1)}k';
    }
    return v.toString();
  }
}

class _GaugePainter extends CustomPainter {
  final double pct;
  final Color color;
  _GaugePainter(this.pct, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height * 0.9;
    final r = size.width * 0.47;
    const startAngle = pi;
    const sweepMax = pi;

    // Track background
    final bgPaint = Paint()
      ..color = AppTheme.bgBar
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: Offset(cx, cy), radius: r),
      startAngle,
      sweepMax,
      false,
      bgPaint,
    );

    // Active arc
    if (pct > 0) {
      final fgPaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..strokeCap = StrokeCap.round;
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        startAngle,
        sweepMax * pct,
        false,
        fgPaint,
      );
    }

    // Tick marks
    final tickPaint = Paint()
      ..color = AppTheme.bgBar
      ..strokeWidth = 1.5;
    for (int i = 0; i <= 10; i++) {
      final angle = pi + (pi * i / 10);
      final inner = r - 14;
      final outer = r - 6;
      canvas.drawLine(
        Offset(cx + inner * cos(angle), cy + inner * sin(angle)),
        Offset(cx + outer * cos(angle), cy + outer * sin(angle)),
        tickPaint,
      );
    }
  }

  @override
  bool shouldRepaint(_GaugePainter old) => old.pct != pct || old.color != color;
}
