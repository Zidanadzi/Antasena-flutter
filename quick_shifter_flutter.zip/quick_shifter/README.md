# Quick Shifter Controller 🏍️

Aplikasi Android untuk mengontrol Quick Shifter berbasis **Arduino Nano V3 + HC-05 Bluetooth**.

Built with Flutter · Tema Midnight Teal

---

## Fitur

- 📡 Koneksi Bluetooth Classic ke HC-05 (SPP)
- 🎛️ RPM gauge real-time dengan zona power
- ⚡ Atur Kill Time (20–150ms) via slider
- 🎯 Atur sensitivitas sensor (ADC 100–900)
- 🔢 Counter total shift per sesi
- 📋 Log komunikasi real-time TX/RX
- 💾 Simpan MAC address terakhir otomatis

---

## Build via GitHub Actions

Setiap push ke branch `main` akan otomatis build APK.

1. Buka tab **Actions** di repo ini
2. Pilih workflow **Build APK**
3. Tunggu ±5 menit
4. Download APK dari **Artifacts** atau **Releases**

---

## Cara Pakai

### Persiapan HC-05
1. Pair HC-05 di **Pengaturan → Bluetooth** HP Android
2. PIN default: `1234` atau `0000`

### Di Aplikasi
1. Buka app → tap chip **"Tidak terhubung"** di atas kanan
2. Pilih perangkat HC-05 dari daftar
3. Setelah terhubung, parameter akan sync otomatis
4. Atur **Kill Time** dan **Sensitivitas** di tab Setting

---

## Wiring Arduino Nano + HC-05

| HC-05 | Arduino Nano |
|-------|-------------|
| VCC | 5V |
| GND | GND |
| TXD | Pin 10 (SoftwareSerial RX) |
| RXD | Pin 11 via voltage divider (1kΩ + 2kΩ) |

> ⚠️ Pin RXD HC-05 hanya toleran 3.3V — wajib pakai voltage divider!

---

## Protokol Komunikasi

**App → Arduino:**
```
SET_KILL:65     → set kill time 65ms
SET_SENS:500    → set threshold sensor
QS_ON           → aktifkan quick shifter
QS_OFF          → nonaktifkan
RESET_COUNT     → reset counter
PING            → cek koneksi
```

**Arduino → App (JSON):**
```json
{"rpm":9240,"shifts":24,"killTime":65,"sensitivity":500,"enabled":true}
{"status":"OK_KILL:65"}
{"status":"SHIFTED:24"}
```

---

## Struktur Project

```
lib/
├── main.dart               # Entry point & shell navigasi
├── theme/app_theme.dart    # Warna & tema Midnight Teal
├── models/arduino_data.dart # Data model & log entry
├── services/bt_service.dart # Bluetooth logic (Provider)
├── screens/
│   ├── dashboard_screen.dart # RPM gauge & stat cards
│   ├── settings_screen.dart  # Slider kill time & sensitivitas
│   ├── log_screen.dart       # Log komunikasi serial
│   └── connect_screen.dart   # Picker perangkat Bluetooth
└── widgets/
    ├── rpm_gauge.dart        # Custom painter gauge
    └── stat_card.dart        # Kartu statistik
```

---

## Dependencies

```yaml
flutter_bluetooth_serial: ^0.4.0  # Bluetooth Classic (HC-05)
permission_handler: ^11.3.0       # Runtime permissions Android
provider: ^6.1.2                  # State management
shared_preferences: ^2.2.3        # Simpan MAC address
```

---

## Lisensi

MIT License — bebas digunakan dan dimodifikasi.
